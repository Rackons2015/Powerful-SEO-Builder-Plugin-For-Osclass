<style type="text/css">
	#content-page { background:#e5e5e5; }
	.col6 { width:48%; float:right; margin:0 10px; }
	.col5 { width:48%; float:left;  margin:0 10px; }
	.form-container { border:2px solid #ddd; background:#fff; }
	.form-container h2 { margin:0; padding:10px 15px; background:#47639e; color:#fff;}
	.form-container fieldset { padding:15px; }
	.form-container .quote { padding:15px; border:1px solid #eee; background:#f9f9f9; margin:15px; }
	.control-group { margin-bottom:15px; }
	.control-label { margin-bottom:5px; display:block; }
	.form-actions { margin-top:15px; margin-bottom:0;}
	.form-horizontal .form-actions { padding-left:15px;}
	.form-container input[type=text] { padding:10px; width:95%; }
	.form-container input[type=text].swidth { width:30%; }
	
	.help { color:#999; font-size:12px; }
	.clearfix { clear:both; }
.rac-header{clear: both;padding: 20px;height: 35px; border:1px #0f0f0f;}
.rac_logo {display: block;float:left;opacity:0.7;}
.rac_logo:hover{opacity:1;}
.follow {float:right;color: #333;}
.follow ul li:first-child {font-weight: bold;position: relative;top: 3px;margin: 0 0 0 20px;}
.follow ul li{float: left;margin: -15px 5px 5px 5px;}
.follow li a{opacity: 0.7;text-align: center;line-height: 1px;display: block;border-radius: 100%;font-size: 13px;-webkit-transition: all 0.3s ease-in-out 0s;-moz-transition: all 0.3s ease-in-out 0s;-ms-transition: all 0.3s ease-in-out 0s;-o-transition: all 0.3s ease-in-out 0s;transition: all 0.3s ease-in-out 0s;}
.follow li a:hover {opacity: 1;}
</style>
<div class="rac-header"> <a href="http://rackons.com/" target="_blank" class="rac_logo"> <img src="http://rackons.com/oc-content/uploads/logo.png" alt="Tap Notification Plugin" title="Tap Notification Plugin" /> </a>
  <div class="follow">
    <ul>
      <li>Follow us <i class="fa fa-hand-o-right"></i></li>
      <li><a href="http://www.facebook.com/rackonscompany" target="_blank" title="facebook"><i class="fa fa-facebook fa-2x"></i> </a></li>
      <li><a href="http://twitter.com/rackonsdotcom" target="_blank" title="twitter"><i class="fa fa-twitter fa-2x"></i> </a></li>
      <li><a href="http://plus.google.com/+RackonsCompany2015" target="_blank" title="google+"><i class="fa fa-google-plus fa-2x"></i> </a></li>

<li><a href="http://osclassmarket.rackons.in" target="_blank" title="Osclass plugins and themes Shop"><i class="fa fa-shopping-bag fa-2x"></i> </a></li>


    </ul>
  </div>
</div>

<div class="clear"></div>	

<div class="plugin-page">
	<div class="col5">
		<?php $pluginInfo = osc_plugin_get_info('powerful_seo_tool/index.php');  ?>
        <div class="form-container">
        <h2 class="render-title"><?php _e('Powerful SEO Builder Plugin Settings', 'powerful_seo_tool'); ?></h2>
        <form action="<?php echo osc_admin_render_plugin_url('powerful_seo_tool/admin.php'); ?>" class="form-horizontal" method="post">
          <input type="hidden" name="powerfuloption" value="powerfulsettings" />
          <fieldset>
         


          <div class="control-group">
            <label class="control-label"><?php _e('Analytic ID', 'powerful_seo_tool'); ?></label>
            <div class="controls">
                <input type="text" class="swidth" name="analytics_id" value="<?php echo osc_esc_html(dd_analytics_id()); ?>">
            </div>
          </div>
        
<p><b>How to get Analytic ID?</b><br>
Step 1 : Login or Signup on <a href="http://seotools.rackons.co.in" target="_blank">SEO Tools</a><br>
Step 2 : After Login please click on Visitor Analysis Submenu in left side.<br>
Step 3 : Click on "Add your site" button<br>
Step 4 : After add your website you can see one Script in Popup. Just copy Data Name id(7 numeric digit) .<br>
Step 5 : Paste your that id on above box. otherwise Rackons Company id will be use.<br>
Note : After put that Analytic Id, You can use Our Powerfull SEO Builder Tools for your site.
</p>
          </fieldset>
          <div class="quote">
           Please put below code on your header.php before &lt;/head&gt; tag<br />
            <pre>&lt;?php powerful_seo_tool(); ?&gt;</pre>

          </div>
          <div class="form-actions">
            <input type="submit" value="<?php _e('Save changes', 'powerful_seo_tool'); ?>" class="btn btn-submit">
          </div>
          
        </form>
        
        </div>

	</div><!-- /Col5 -->
    
    <div class="col6">
    	<div id="powerful" class="promobox">
<div class="form-container">
        <h2 class="render-title"><?php _e('Other SEO Tools', 'powerful_seo_tool'); ?></h2>
       <ul>
<li> &#10004; Backlink & Ping : Unlimited</li>
<li>  &#10004; Domain Analysis : Unlimited</li>
 <li> &#10004; Google Adwords Scraper : Unlimited</li>
 <li> &#10004; IP Analysis : Unlimited</li>
 <li> &#10004; Keyword Analysis : Unlimited</li>
 <li> &#10004; Keyword Position Tracking</li>
 <li> &#10004; Link Analysis : Unlimited</li>
 <li> &#10004; Malware Scan : Unlimited</li>
 <li> &#10004; Native API : Unlimited</li>
 <li> &#10004; Native Widget</li>
 <li> &#10004; Plagiarism Check : Unlimited</li>
 <li> &#10004; Rank & Index Analysis : Unlimited</li>
 <li> &#10004; Social Network Analysis : Unlimited</li>
 <li> &#10004; Utilities</li>
 <li> &#10004; Visitor Analytics : Unlimited</li>
 <li> &#10004; Website Analysis : Unlimited</li>
</ul>
<center><a href="http://seotools.rackons.co.in/home/login" target="_blank">
<button class="button" style="vertical-align:middle"><span>Join Now </span></button></a></center>
        </div>
			<?php echo dd_powerful_related();?>
        </div>
    </div><!-- /COL6 -->
    <div class="clearfix"></div>
</div>
<div class="footer">
    <p class="form-row">
    &copy; <?php echo date('Y'); ?> Powerful SEO Builder Plugin - <a href="http://osclassmarket.rackons.in/osclass-support" target="_blank"><?php _e('Support', 'powerful_plugin'); ?></a> - <a href="http://osclassmarket.rackons.in/">Rackons Market</a>.
    </p>
</div>
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/56517ac8c4f9dae563617825/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
<style>
.button {
  display: inline-block;
  border-radius: 4px;
  background-color: #f4511e;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 28px;
  padding: 20px;
  width: 200px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
}

.button span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

.button span:after {
  content: '\00bb';
  position: absolute;
  opacity: 0;
  top: 0;
  right: -20px;
  transition: 0.5s;
}

.button:hover span {
  padding-right: 25px;
}

.button:hover span:after {
  opacity: 1;
  right: 0;
}
</style>